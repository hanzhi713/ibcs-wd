﻿Public Class Form1
    Public calculateddays As Integer = 0
    Dim years As Integer = 0
    Dim months As Integer = 0
    Dim days As Integer = 0
    Dim yeare As Integer = 0
    Dim monthe As Integer = 0
    Dim daye As Integer = 0
    Dim isleap As Boolean = False
    Public Sub StartMonthDayCalc(ByVal month As Integer)
        Select Case month
            Case 1
                calculateddays += 31 - days
            Case 2
                If isleap = True Then
                    calculateddays += 29 - days
                Else
                    calculateddays += 28 - days
                End If
            Case 3
                calculateddays += 31 - days
            Case 4
                calculateddays += 30 - days
            Case 5
                calculateddays += 31 - days
            Case 6
                calculateddays += 30 - days
            Case 7
                calculateddays += 31 - days
            Case 8
                calculateddays += 31 - days
            Case 9
                calculateddays += 30 - days
            Case 10
                calculateddays += 31 - days
            Case 11
                calculateddays += 30 - days
            Case 12
                calculateddays += 31 - days
        End Select
        calculateddays += 1
    End Sub
    Public Sub DaysBetwMonthCalc(ByVal stratmonth As Integer, ByVal endmonth As Integer)
        Do Until stratmonth = endmonth
            Select Case stratmonth
                Case 1
                    calculateddays += 31
                Case 2
                    If isleap = True Then
                        calculateddays += 29
                    Else
                        calculateddays += 28
                    End If
                Case 3
                    calculateddays += 31
                Case 4
                    calculateddays += 30
                Case 5
                    calculateddays += 31
                Case 6
                    calculateddays += 30
                Case 7
                    calculateddays += 31
                Case 8
                    calculateddays += 31
                Case 9
                    calculateddays += 30
                Case 10
                    calculateddays += 31
                Case 11
                    calculateddays += 30
                Case 12
                    calculateddays += 31
            End Select
            stratmonth += 1
        Loop
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        On Error GoTo e
        years = TextBox1.Text
        months = TextBox2.Text
        days = TextBox3.Text
        yeare = TextBox4.Text
        monthe = TextBox5.Text
        daye = TextBox6.Text
        isleap = False
        calculateddays = 0
        If Int(years / 4) = years / 4 Then
            isleap = True
        Else
            isleap = False
        End If
        If Int(years / 100) = years / 100 And Int(years / 400) <> years / 400 Then isleap = False
        If TextBox1.Text = TextBox4.Text And TextBox2.Text IsNot TextBox5.Text Then
            Call StartMonthDayCalc(months)
            Call DaysBetwMonthCalc(months + 1, monthe)
            MsgBox(calculateddays)
        ElseIf TextBox1.Text = TextBox4.Text And TextBox2.Text = TextBox5.Text Then
            calculateddays = daye - days + 1
            MsgBox(calculateddays)
        Else
            Call StartMonthDayCalc(months)
            Call DaysBetwMonthCalc(months + 1, 13)
            Do Until years = yeare - 1
                years += 1
                If Int(years / 4) = years / 4 Then
                    isleap = True
                Else
                    isleap = False
                End If
                If Int(years / 100) = years / 100 And Int(years / 400) <> years / 400 Then isleap = False
                If isleap = True Then
                    calculateddays += 366
                Else
                    calculateddays += 365
                End If
            Loop
            Call DaysBetwMonthCalc(1, monthe)
            calculateddays += daye
            MsgBox(calculateddays)
        End If
        Exit Sub
e:
        MsgBox("错误！请检查您的输入！", vbCritical, "警告")
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class

import pygame
import sys
import random
import time
import math
from pygame.locals import *

class Background:
    def __init__(self,image,pos=(420,315)):
        self.name=image
        self.sprite0=pygame.transform.scale(pygame.image.load(image),(800,600))
        self.x,self.y=pos
        self.x0=0
        self.y0=0
        
    def show(self,i):
        self.sprite=pygame.transform.scale(self.sprite0,(8*i,6*i))
        self.x-=20
        self.y-=15
        Surface.blit(self.sprite,(self.x,self.y))
        
    def draw(self):
        Surface.blit(self.sprite0,(self.x0,self.y0))

class Sprite:
    def __init__(self,image,lr='l',hight=600,pos=(0,0,100),blood=100):
        self.blood=blood
        self.name=image
        self.sprite0=pygame.image.load(image)
        self.h0=600
        self.w0=int(self.sprite0.get_width()/self.sprite0.get_height()*600)
        self.ratio=self.w0/self.h0
        self.sprite0=pygame.transform.scale(self.sprite0,(self.w0,self.h0))
        x,y,z=pos
        self.x=x
        if lr=='l':
            self.x0=0
        else:
            self.x0=800-self.sprite0.get_width()
        self.y=y
        self.y0=0
        self.z=z
        self.speed=10
        self.sprite=pygame.image.load(image)
        self.h=hight
        self.w=self.h*self.ratio
        self.sprite=pygame.transform.scale(self.sprite,(int(self.w),int(self.h)))
        self.rect=pygame.Surface.get_rect(self.sprite)
        self.image=self.sprite
        
    def __str__(self):
        return "I'm {0} pos={1} size={2}".format(self.name,(self.x,self.y,self.z),(self.w,self.h))
        
    def move_x(self,dis):
        self.x+=dis

    def move_y(self,dis):
        self.y+=dis

    def move_z(self,dis):
        dh=dis*10
        dw=dh*self.ratio
        if self.w+dw<=10 or self.h+dh<=10 or self.z+dis>=100 or self.z+dis<=0:
            dw=0
            dh=0
            dis=0
        self.z+=dis
        self.w+=dw
        self.h+=dh
        self.x-=dw//2
        self.y-=dh//3
        self.speed+=dis/10
        
    def draw(self):
        self.sprite=pygame.image.load(self.name)
        self.sprite=pygame.transform.scale(self.sprite,(int(self.w),int(self.h)))
        Surface.blit(self.sprite,(self.x,self.y))
        
    def front(self):
        Surface.blit(self.sprite0,(self.x0,self.y0))

    def herodeath(self):
        global monsterwaves
        if self.blood<=10:
##            self.kill()
            return True
        for i in monsterwaves:
            if pygame.sprite.collide_mask(self,i):
                Surface.fill((255,0,0))
                self.blood-=10
        return False
    def monsterdeath(self):
        global herowaves
        if self.blood<=10:
##            self.kill()
            return True
        for i in herowaves:
            if pygame.sprite.collide_mask(self,i):
                Surface.fill((0,255,0))
                self.blood-=10
        return False

    def say(self,l1='',l2='',l3='',l4='',back=None):
        global dialogue,system
        done=0
        while not done:
            if back==None:
                back=system
            back.draw()
            self.front()
            dialogue.write(1,l1)
            dialogue.write(2,l2)
            dialogue.write(3,l3)
            dialogue.write(4,l4)
            dialogue.draw()
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                    break
                if ev.type == pygame.MOUSEBUTTONDOWN:
                    done=1
                    break
            my_clock.tick(60)
            pygame.display.flip()
class Word:
    def __init__(self,linenum,content):
        self.linenum=linenum
        self.content=content
        self.y=390+linenum*35
        
    def show(self):
        self.sprite = my_font.render(self.content, True, (255,255,0))
        Surface.blit(self.sprite,(100,self.y))
        
class Dialogue:
    def __init__(self,image='dialogue.gif'):
        self.sprite=pygame.image.load(image)
        self.sprite=pygame.transform.scale(self.sprite,(800,200))
        self.line1=Word(1,'')
        self.line2=Word(2,'')
        self.line3=Word(3,'')
        self.line4=Word(4,'')
    def write(self,linenum,newcontent):
        if linenum==1:
            self.line1.content=newcontent
        if linenum==2:
            self.line2.content=newcontent
        if linenum==3:
            self.line3.content=newcontent
        if linenum==4:
            self.line4.content=newcontent
    def draw(self):
        Surface.blit(self.sprite,(0,400))
        Surface.blit(note_font.render('Click to continue >>', True, (255,255,0)),(610,545))
        for i in [self.line1,self.line2,self.line3,self.line4]:
            i.show()

class Wave():
    def __init__(self,image,gb,pos,angle=0):
        self.sprite=pygame.image.load(image)
        self.x,self.y=pos
        if gb:
            self.angle=angle
            self.dx=math.cos(math.radians(angle))
            self.dy=math.sin(math.radians(angle))
        if not gb:
            rng=random.Random()
            self.dx=rng.uniform(-1,1)
            self.dy=rng.uniform(-1,1)
            self.angle=math.degrees(math.atan(self.dx/(self.dy+0.1)))
        self.sprite=pygame.transform.rotate(self.sprite,self.angle)
        self.rect=pygame.Surface.get_rect(self.sprite)
        self.image=self.sprite
        
    def update(self):
        self.x+=self.dx
        self.y+=self.dy
        Surface.blit(self.sprite,(int(self.x),int(self.y)))

##    def herowavedeath(self):
##        global monster
##        if self.x<0 or self.x>800 or self.y<0 or self.y>600:
##            self.kill()
##        if pygame.sprite.collide_mask(self,monster)!=None:
##            self.kill()
##    def monsterwavedeath(self):
##        global hero
##        if self.x<0 or self.x>800 or self.y<0 or self.y>600:
##            self.kill()
##        if pygame.sprite.collide_mask(self,hero)!=None:
##            self.kill()

def init_star():
    dir = random.randrange(100000)
    velmult = random.random()*.6+.4
    vel = [math.sin(dir) * velmult, math.cos(dir) * velmult]
    return vel, WINCENTER[:]
def initialize_stars():
    stars = []
    for x in range(NUMSTARS):
        star = init_star()
        vel, pos = star
        steps = random.randint(0, WINCENTER[0])
        pos[0] = pos[0] + (vel[0] * steps)
        pos[1] = pos[1] + (vel[1] * steps)
        vel[0] = vel[0] * (steps * .09)
        vel[1] = vel[1] * (steps * .09)
        stars.append(star)
    move_stars(stars)
    return stars
def draw_stars(surface, stars, color):
    for vel, pos in stars:
        pos = (int(pos[0]), int(pos[1]))
        surface.set_at(pos, color)
def move_stars(stars):
    for vel, pos in stars:
        pos[0] = pos[0] + vel[0]
        pos[1] = pos[1] + vel[1]
        if not 0 <= pos[0] <= WINSIZE[0] or not 0 <= pos[1] <= WINSIZE[1]:
            vel[:], pos[:] = init_star()
        else:
            vel[0] = vel[0] * 1.05
            vel[1] = vel[1] * 1.05
            
def introduction():
    global dialogue
    dialogue=Dialogue()
    random.seed()
    stars = initialize_stars()
    clock = pygame.time.Clock()
    pygame.display.set_caption('StarWar')
    white = 255, 240, 200
    black = 20, 20, 40
    Surface.fill(black)
    done = 0
    while not done:
        draw_stars(Surface, stars, black)
        move_stars(stars)
        draw_stars(Surface, stars, white)
        dialogue.write(1,'In 2000 B.C., the universe is dominated by a kind of evil creature.')
        dialogue.write(2,'They call themselves -- Trumps.')
        dialogue.write(3,"We've been exiled for too long...")
        dialogue.write(4,"Now, our worrier! It's time to take our world back!")
        dialogue.draw()
        pygame.display.update()
        for ev in pygame.event.get():
            if ev.type == pygame.MOUSEBUTTONDOWN:
                done=1
                break
            if ev.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
                break
        my_clock.tick(60)
        pygame.display.flip()

def transition():
    global system
    i=0
    while i<=100:
        system.show(i)
        i+=5
        ev=pygame.event.poll()
        if ev.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
            break
        my_clock.tick(10)
        pygame.display.flip()

def mainmenu(completed):
    global system
    while True:
        system.draw()
        for i in completed:
            sword=pygame.transform.scale(pygame.image.load('sword.gif'),dic[i][0])
            Surface.blit(sword,dic[i][1])
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
                break
            if ev.type == pygame.MOUSEBUTTONDOWN:
                x,y=pygame.mouse.get_pos()
                if 20<x<120 and 240<y<300:
                    return 'water'
                if 150<x<250 and 210<y<310:
                    return 'gold'
                if 284<x<454 and 118<y<246:
                    return 'earth'
                if 396<x<523 and 12<y<100:
                    return 'fire'
                if 20<x<250 and 420<y<590:
                    return 'wood'
                if 281<x<515 and 366<y<526:
                    return 'dust'
                if 500<x<680 and 240<y<375:
                    return 'sky'
                if 625<x<770 and 75<y<205:
                    return 'sea'
        my_clock.tick(60)
        pygame.display.flip()
        
def battle(star):
    global completed,monsterwaves,herowaves,hero,monster
    planet=Background(star+'.gif')
    hero.say('Ha!','Find ya!',back=planet)
    monster.say('Come and die!',back=planet)
    monsterwaves=[]
    herowaves=[]
    hero=Sprite('back.gif')
    monster=Sprite('monster.gif',hight=300,pos=(400,100,0))
    frame=0
    while True:
        planet.draw()
        for i in monsterwaves:
            i.update()
        for i in herowaves:
            i.update()
        frame+=1
        if frame%40==0:
            monsterwave=Wave('monsterwave.gif',False,(monster.x,monster.y))
            monsterwaves.append(monsterwave)
        monster.draw()
        hero.draw()
        for ev in pygame.event.get():
            if ev.type == pygame.KEYDOWN:
                if ev.dict['key']==273:
                    if pygame.key.get_mods()==1 or pygame.key.get_mods()==2:
                        hero.move_z(-hero.speed)
                    else:
                        hero.move_y(-hero.speed)
                if ev.dict['key']==274:
                    if pygame.key.get_mods()==1 or pygame.key.get_mods()==2:
                        hero.move_z(hero.speed)
                    else:
                        hero.move_y(hero.speed)
                if ev.dict['key']==275:
                    hero.move_x(hero.speed)
                if ev.dict['key']==276:
                    hero.move_x(-hero.speed)
            if ev.type == pygame.MOUSEBUTTONDOWN:
                x,y=pygame.mouse.get_pos()
                a,b=hero.x,hero.y
                angle=math.degrees(math.atan((x-a)/(y-b)))
                herowave=Wave('herowave.gif',True,(hero.x,hero.y),angle)
                herowaves.append(herowave)
            if ev.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
                break
        if monster.monsterdeath():
            completed.append(star)
            monster.say('NO!!!',"I'll be back!!!")
            return None
        if hero.herodeath():
            monster.say('Unlimited power!!','Ha Ha!',"The universe is ours!!!")
            hero.say('Uhh!!!','Revenge me!!!')
            gg=Background('gg.gif')
            gg.draw()
            pygame.display.flip()
            time.sleep(3)
            pygame.quit()
            sys.exit()
##        for i in monsterwaves:
##            i.monsterwavedeath()
##        for i in herowaves:
##            i.herowavedeath()
        my_clock.tick(20)
        pygame.display.flip()
        
if __name__ == '__main__':
    #setup
    WINSIZE = [800, 600]
    WINCENTER = [400, 300]
    NUMSTARS = 150
    pygame.init()
    pygame.key.set_repeat(True)
    system=Background("system.gif")
    monster=Sprite('monster.gif','l')
    hero=Sprite('front.gif','r')
    my_clock = pygame.time.Clock()
    Surface=pygame.display.set_mode((800,600))
    my_font = pygame.font.SysFont('Times New Roman',18,True)
    note_font=pygame.font.SysFont('Times New Roman',12,False)
    completed=[]
    dic={'water':((95,64),(22,241)),'gold':((111,96),(146,211)),'earth':((170,128),(284,118)),'fire':((127,88),(396,12)),'wood':((229,171),(20,400)),'dust':((233,160),(281,366)),'sky':((179,137),(504,238)),'sea':((143,130),(626,75))}
    #begin
    introduction()
    transition()
    monster.say('Mortal man. Here is not where you should be.',"Go back, and never come again.")
    hero.say("I'm not afraid of you, scum.",'The universe is ours.','Prepare to die!')
    while True:
        star=mainmenu(completed)
        hero=Sprite('front.gif','r')
        battle(star)
        if len(completed)==8:
            hero.say("Finally... here is peace.",'The man kind will live happily ever after.')
            win=Background('win.gif')
            win.draw()
            pygame.display.flip()
            time.sleep(3)
            pygame.quit()
            sys.exit()
            break

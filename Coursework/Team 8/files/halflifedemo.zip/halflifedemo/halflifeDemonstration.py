class atom():
    def __init__(self, halflife=1.0):
        import random
        self.hasdecayed = False
        self.halflife = halflife
        self.xcor = int(random.uniform(20, 620) + 0.5)
        self.ycor = int(random.uniform(20, 460) + 0.5)

    def decay(self):
        import random
        if not self.hasdecayed:
            if random.uniform(0, 1) > 0.5 ** (1.0 / (24.0 * self.halflife)):
                self.hasdecayed = True
                return True
        return False

    def show(self):
        if self.hasdecayed == False:
            screen.blit(alive, (self.xcor, self.ycor))
        else:
            screen.blit(decayed, (self.xcor, self.ycor))

    def refresh(self):
        self.hasdecayed = False

    def __print__(self):
        if hasdecayed:
            print("This is has decayed.")
        else:
            print("This is still present.")


class decayExperiment():
    atoms = []

    def __init__(self, dose=100, halflife=10):
        self.dose = dose
        self.remain = dose
        for i in range(dose):
            self.atoms.append(atom(halflife))

    def show(self):
        for i in self.atoms:
            i.show()

    def decay(self):
        import sys
        counttime=0
        while 1:
            screen.fill([255,255,255])
            for i in self.atoms:
                if i.decay():
                    self.remain -= 1
            self.show()
            time.sleep(1/24)
            counttime+=1/24
            text_screen = my_font.render("Time lapse: "+str(counttime), True, (255, 0, 0))
            screen.blit(text_screen, (0, 0))
            board2 = "Remaining atoms: "+str(self.remain)+" of "+str(self.dose)
            text_screen = my_font.render(board2, True, (255, 0, 0))
            screen.blit(text_screen, (320, 0))
            pygame.display.flip()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
            if self.remain <= self.dose*0.01:
                print("99% has already decayed!")
                break

    def refresh(self):
        self.remain=self.dose
        for i in self.atoms:
            i.refresh()
        screen.fill([255, 255, 255])
        pygame.display.flip()


import pygame
import time
from pygame.locals import *

pygame.init()
screen = pygame.display.set_mode([640, 480])
screen.fill([255, 255, 255])
my_font = pygame.font.SysFont(None, 22)
pygame.display.set_caption("Halflife Demonstration")
alive = pygame.image.load('red.gif')
alive = pygame.transform.scale(alive, (20, 20))
decayed = pygame.image.load('black.gif')
decayed = pygame.transform.scale(decayed, (20, 20))
pygame.display.flip()


while 1:
    elenum = int(input("How many atoms? (100 to 1000 recommended)"))
    elelife = float(input("How long is the halflife in seconds? (1.0 above recommended)"))
    experiment = decayExperiment(elenum, elelife)
    experiment.decay()
    time.sleep(5)
    experiment.refresh()
    iscontinue = input("Again?")
    if iscontinue == "no":
        break

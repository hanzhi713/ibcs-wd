
public class Driver {
	static Room[] allRooms = new Room[100];
	public static void main(String[] args){
		for(int i = 0; i < 100; i++){
			allRooms[i] = new Room(i + 1, (int) (3 * Math.random()), 90.0, true);
		}
		Group g1 = new Group("Happy Travellers", 15);
		GClient[] gc = new GClient[15];
		int[] available = findRooms();
		for(int i = 0; i < 15; i ++){
			allRooms[available[i] - 1].setEmpty(false);
			int a = allRooms[available[i] - 1].getRoomNumber();
			gc[i].setBedroom(new Room(a));
		}
		}
	public static int[] findRooms(){
		int[] available = new int[100];
		int j = 0;
		for(Room r: allRooms){
			if (r.getBeds() == 2 && r.getEmpty()){
					available[j] = r.getRoomNumber();
					j = j + 1;
			}
			
		}
		return available;
	}
}


public class Room {
	private int roomNumber;
	private int beds;
	private double price;
	private Boolean empty;
	public Room(int no, int beds, double price, Boolean empty){
		this.roomNumber = no;
		this.beds = beds;
		this.price = price;
		this.empty = empty;
	}
	public void setRoomNumber(int n){roomNumber = n;}
	public void setBeds(int b){beds = b;}
	public void setPrice(int n){price = n;}
	public void setEmpty(Boolean e){empty = e;}
	public int getRoomNumber(){return roomNumber;}
	public int getBeds(){return beds;}
	public double getPrice(){return price;}
	public Boolean getEmpty(){return empty;};

}

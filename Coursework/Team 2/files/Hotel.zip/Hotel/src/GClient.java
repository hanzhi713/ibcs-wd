
public class GClient extends Client{
	private String groupName;
	public GClient(int id, String c, Dates dateIn, Dates dateOut, Room r, String g) {
		super(id, c, dateIn, dateOut, r);
		groupName = g;
	}
	public void setGroupName(String gN){
		groupName = gN;
	}
	public String getGroupName(){
		return groupName;
	}

}

public class AirplaneJourney extends Journey {
    public AirplaneJourney(String routeCode, int delay, boolean weatherRelated) {
        super(routeCode, delay, weatherRelated);
    }
}

public class TrainCompany {
    private String companyName;
    private String companyCode;
    private int numberOfJourneys;
    private Journey[] journeyHistory = new Journey[100000];

    public TrainCompany(String companyName, String companyCode) {
        this.companyName = companyName;
        this.companyCode = companyCode;
        this.numberOfJourneys = 0;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public int getNumberOfJourneys() {
        return numberOfJourneys;
    }

    public void addJourney(Journey j) {
        journeyHistory[numberOfJourneys++] = j;
    }

    public Journey getJourney(int x) {
        return journeyHistory[x];
    }

    public double averageDelay() {
        double sumDelay = 0;
        int count = 0;
        for (int i = 0; i < numberOfJourneys; i++) {
            Journey j = journeyHistory[i];
            if (!j.isWeatherRelated()) {
                sumDelay += j.getDelay();
                count++;
            }
        }
        return sumDelay / count;
    }

    public String longestDelay(Codes[] c) {
        int maxDelay = 0;
        Journey longestDelayJourney = null;
        for (int i = 0; i < numberOfJourneys; i++) {
            Journey j = journeyHistory[i];
            if (!j.isWeatherRelated()) {
                if (j.getDelay() > maxDelay) {
                    maxDelay = j.getDelay();
                    longestDelayJourney = j;
                }
            }
        }
        if (longestDelayJourney == null)
            return null;
        for (Codes code : c) {
            if (code.getRouteCode().equals(longestDelayJourney.getRouteCode()))
                return code.getRouteName();
        }
        return null;
    }

    public String toString(Codes[] c) {
        return companyName + " : Average Delay = " + averageDelay() + " minutes : Longest Delay = " + longestDelay(c);
    }

}

public class BusJourney extends Journey {
    public BusJourney(String routeCode, int delay, boolean weatherRelated) {
        super(routeCode, delay, weatherRelated);
    }
}

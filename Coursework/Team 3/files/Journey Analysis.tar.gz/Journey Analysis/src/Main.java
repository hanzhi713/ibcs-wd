import com.sun.org.apache.bcel.internal.classfile.Code;

import java.util.ArrayList;
import java.util.Arrays;

public class Main {
    private static Codes allCodes[] = new Codes[10000];

    public static void main(String... args) {
        TrainCompany[] allCompanies = new TrainCompany[3];
        allCompanies[0] = new TrainCompany("Southern", "T290");
        allCompanies[1] = new TrainCompany("Northern", "T400");
        allCompanies[2] = new TrainCompany("Eastern", "T155");

        Journey s = new Journey("J100", 3, false);
        Journey t = new Journey("J103", 8, true);
        Journey u = new Journey("J104", 10, true);

        allCompanies[0].addJourney(s);
        allCompanies[1].addJourney(t);
        allCompanies[0].addJourney(u);
        allCompanies[0].addJourney(new Journey("J101", 6, false));

        allCodes[0] = new Codes("Alex - Doris", "J100");
        allCodes[1] = new Codes("Charles - Tom", "J101");
        allCodes[2] = new Codes("Michael - Margaret", "J102");
        allCodes[3] = new Codes("Enzo - Arthur", "J103");
        allCodes[4] = new Codes("David - Matt", "J104");
        allCodes[5] = new Codes("Charles - Tom", "J101");
        allCodes[6] = new Codes("Michael - Margaret", "J102");

        System.out.println(allCompanies[0].getCompanyCode());
        System.out.println(allCompanies[0].getJourney(1).getDelay());
        System.out.println(allCompanies[1].getNumberOfJourneys());

        System.out.println(allCompanies[0].toString(allCodes));

        System.out.println("allCodes before convert() is called");
        System.out.println(Arrays.toString(allCodes));
        System.out.println("allCodes after convert() is called");
        System.out.println(Arrays.toString(convert().toArray()));
    }

    public static ArrayList<Codes> convert() {
        ArrayList<Codes> uniqueCodes = new ArrayList<>();
        for (Codes c : allCodes) {
            if (c == null) break;
            boolean isDuplication = false;
            for (Codes uc : uniqueCodes) {
                if (uc.equals(c)) {
                    isDuplication = true;
                    break;
                }
            }
            if (!isDuplication) {
                uniqueCodes.add(c);
            }
        }
        return uniqueCodes;
    }
}

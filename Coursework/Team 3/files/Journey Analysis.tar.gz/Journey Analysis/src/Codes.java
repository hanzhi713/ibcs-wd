public class Codes {
    private String routeName;
    private String routeCode;

    public Codes(String routeName, String routeCode) {
        this.routeName = routeName;
        this.routeCode = routeCode;
    }

    public String getRouteCode() {
        return routeCode;
    }

    public void setRouteCode(String routeCode) {
        this.routeCode = routeCode;
    }

    public String getRouteName() {
        return routeName;
    }

    public void setRouteName(String routeName) {
        this.routeName = routeName;
    }

    public boolean equals(Codes other){
        return other.getRouteCode().equals(routeCode);
    }

    @Override
    public String toString() {
        return routeCode + " " + routeName;
    }
}

package tictactoe;
import java.util.Scanner;
/**
 * Created by Matt An on 2016/12/20.
 */
public class Main {
    public static boolean personturn=true;
    public static boolean personwon=false;
    public static boolean computerwon=false;
    public static UI board=new UI();
    public static Scanner input=new Scanner(System.in);
    public static boolean playagain=false;
    public static void win() {
        if (board.botton1.getText().equals("X")) {
            if (board.botton4.getText().equals("X")) {
                if (board.botton7.getText().equals("X")) {
                    personwon=true;
                    computerwon=false;
                    System.out.println("You win!");
                }
            }
        }
        if (board.botton1.getText().equals("X")) {
            if (board.botton5.getText().equals("X")) {
                if (board.botton9.getText().equals("X")) {
                    personwon=true;
                    computerwon=false;
                    System.out.println("You win!");
                }
            }
        }
        if (board.botton1.getText().equals("X")) {
            if (board.botton2.getText().equals("X")) {
                if (board.botton3.getText().equals("X")) {
                    personwon=true;
                    computerwon=false;
                    System.out.println("You win!");
                }
            }
        }
        if (board.botton2.getText().equals("X")) {
            if (board.botton5.getText().equals("X")) {
                if (board.botton8.getText().equals("X")) {
                    personwon=true;
                    computerwon=false;
                    System.out.println("You win!");
                }
            }
        }
        if (board.botton3.getText().equals("X")) {
            if (board.botton6.getText().equals("X")) {
                if (board.botton9.getText().equals("X")) {
                    personwon=true;
                    computerwon=false;
                    System.out.println("You win!");
                }
            }
        }
        if (board.botton4.getText().equals("X")) {
            if (board.botton5.getText().equals("X")) {
                if (board.botton6.getText().equals("X")) {
                    personwon=true;
                    computerwon=false;
                    System.out.println("You win!");
                }
            }
        }
        if (board.botton7.getText().equals("X")) {
            if (board.botton8.getText().equals("X")) {
                if (board.botton9.getText().equals("X")) {
                    personwon=true;
                    computerwon=false;
                    System.out.println("You win!");
                }
            }
        }
        if (board.botton3.getText().equals("X")) {
            if (board.botton5.getText().equals("X")) {
                if (board.botton7.getText().equals("X")) {
                    personwon=true;
                    computerwon=false;
                    System.out.println("You win!");
                }
            }
        }
        if (board.botton1.getText().equals("O")) {
            if (board.botton4.getText().equals("O")) {
                if (board.botton7.getText().equals("O")) {
                    personwon=false;
                    computerwon=true;
                    System.out.println("Sorry,you lose.");
                }
            }
        }
        if (board.botton1.getText().equals("O")) {
            if (board.botton5.getText().equals("O")) {
                if (board.botton9.getText().equals("O")) {
                    personwon=false;
                    computerwon=true;
                    System.out.println("Sorry,you lose.");
                }
            }
        }
        if (board.botton1.getText().equals("O")) {
            if (board.botton2.getText().equals("O")) {
                if (board.botton3.getText().equals("O")) {
                    personwon=false;
                    computerwon=true;
                    System.out.println("Sorry,you lose.");
                }
            }
        }
        if (board.botton2.getText().equals("O")) {
            if (board.botton5.getText().equals("O")) {
                if (board.botton8.getText().equals("O")) {
                    personwon=false;
                    computerwon=true;
                    System.out.println("Sorry,you lose.");
                }
            }
        }
        if (board.botton3.getText().equals("O")) {
            if (board.botton6.getText().equals("O")) {
                if (board.botton9.getText().equals("O")) {
                    personwon=false;
                    computerwon=true;
                    System.out.println("Sorry,you lose.");
                }
            }
        }
        if (board.botton4.getText().equals("O")) {
            if (board.botton5.getText().equals("O")) {
                if (board.botton6.getText().equals("O")) {
                    personwon=false;
                    computerwon=true;
                    System.out.println("Sorry,you lose.");
                }
            }
        }
        if (board.botton7.getText().equals("O")) {
            if (board.botton8.getText().equals("O")) {
                if (board.botton9.getText().equals("O")) {
                    personwon=false;
                    computerwon=true;
                    System.out.println("Sorry,you lose.");
                }
            }
        }
        if (board.botton3.getText().equals("O")) {
            if (board.botton5.getText().equals("O")) {
                if (board.botton7.getText().equals("O")) {
                    personwon=false;
                    computerwon=true;
                    System.out.println("Sorry,you lose.");
                }
            }
        }
    }
    public static void main(String[] args){
        if (board.isVisible()==false) {
            board.setVisible(true);
        }
        while(personwon==true||computerwon==true){
            board.setVisible(false);
            System.out.println("Play again?");
            playagain=input.nextBoolean();
            if(playagain==true){
                personwon=false;
                computerwon=false;
                personturn=true;
                board.botton1.setText("");
                board.botton2.setText("");
                board.botton3.setText("");
                board.botton4.setText("");
                board.botton5.setText("");
                board.botton6.setText("");
                board.botton7.setText("");
                board.botton8.setText("");
                board.botton9.setText("");
            }
        }
    }
}

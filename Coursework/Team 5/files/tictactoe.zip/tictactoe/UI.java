package tictactoe;

/**
 * Created by Matt An on 2016/12/20.
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle;
public class UI extends JFrame{
    public UI(){
        initialboard();
    }
    public void botton1ActionPerformed(ActionEvent e) {
        if(botton1.getText().equals("")){
            if(Main.personturn==true){
                botton1.setText("X");
                Main.win();
                Main.personturn=false;
            }
            else{
                botton1.setText("O");
                Main.win();
                Main.personturn=true;
            }
        }
    }
    public void botton2ActionPerformed(ActionEvent e) {
        if(botton2.getText().equals("")){
            if(Main.personturn==true){
                botton2.setText("X");
                Main.win();
                Main.personturn=false;
            }
            else{
                botton2.setText("O");
                Main.win();
                Main.personturn=true;
            }
        }
    }
    public void botton3ActionPerformed(ActionEvent e) {
        if(botton3.getText().equals("")){
            if(Main.personturn==true){
                botton3.setText("X");
                Main.win();
                Main.personturn=false;
            }
            else{
                botton3.setText("O");
                Main.win();
                Main.personturn=true;
            }
        }
    }
    public void botton4ActionPerformed(ActionEvent e) {
        if(botton4.getText().equals("")){
            if(Main.personturn==true){
                botton4.setText("X");
                Main.win();
                Main.personturn=false;
            }
            else{
                botton4.setText("O");
                Main.win();
                Main.personturn=true;
            }
        }
    }
    public void botton5ActionPerformed(ActionEvent e) {
        if(botton5.getText().equals("")){
            if(Main.personturn==true){
                botton5.setText("X");
                Main.win();
                Main.personturn=false;
            }
            else{
                botton5.setText("O");
                Main.win();
                Main.personturn=true;
            }
        }
    }
    public void botton6ActionPerformed(ActionEvent e) {
        if(botton6.getText().equals("")){
            if(Main.personturn==true){
                botton6.setText("X");
                Main.win();
                Main.personturn=false;
            }
            else{
                botton6.setText("O");
                Main.win();
                Main.personturn=true;
            }
        }
    }
    public void botton7ActionPerformed(ActionEvent e) {
        if(botton7.getText().equals("")){
            if(Main.personturn==true){
                botton7.setText("X");
                Main.win();
                Main.personturn=false;
            }
            else{
                botton7.setText("O");
                Main.win();
                Main.personturn=true;
            }
        }
    }
    public void botton8ActionPerformed(ActionEvent e) {
        if(botton8.getText().equals("")){
            if(Main.personturn==true){
                botton8.setText("X");
                Main.win();
                Main.personturn=false;
            }
            else{
                botton8.setText("O");
                Main.win();
                Main.personturn=true;
            }
        }
    }
    public void botton9ActionPerformed(ActionEvent e) {
        if(botton9.getText().equals("")){
            if(Main.personturn==true){
                botton9.setText("X");
                Main.win();
                Main.personturn=false;
            }
            else{
                botton9.setText("O");
                Main.win();
                Main.personturn=true;
            }
        }
    }
    Main main=new Main();
    public JButton botton1;
    public JButton botton2;
    public JButton botton3;
    public JButton botton4;
    public JButton botton5;
    public JButton botton6;
    public JButton botton7;
    public JButton botton8;
    public JButton botton9;
    public void initialboard(){
        botton1=new JButton();
        botton2=new JButton();
        botton3=new JButton();
        botton4=new JButton();
        botton5=new JButton();
        botton6=new JButton();
        botton7=new JButton();
        botton8=new JButton();
        botton9=new JButton();
        setTitle("Tic-Tac-Toe");
        botton1.setText("");
        botton1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                botton1ActionPerformed(e);
            }
        });
        botton2.setText("");
        botton2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                botton2ActionPerformed(e);
            }
        });
        botton3.setText("");
        botton3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                botton3ActionPerformed(e);
            }
        });
        botton4.setText("");
        botton4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                botton4ActionPerformed(e);
            }
        });
        botton5.setText("");
        botton5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                botton5ActionPerformed(e);
            }
        });
        botton6.setText("");
        botton6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                botton6ActionPerformed(e);
            }
        });
        botton7.setText("");
        botton7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                botton7ActionPerformed(e);
            }
        });
        botton8.setText("");
        botton8.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                botton8ActionPerformed(e);
            }
        });
        botton9.setText("");
        botton9.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                botton9ActionPerformed(e);
            }
        });

        GroupLayout contentPaneLayout = new GroupLayout(this.getContentPane());
        this.getContentPane().setLayout(contentPaneLayout);
        contentPaneLayout.setHorizontalGroup(
                contentPaneLayout.createParallelGroup()
                        .addGroup(contentPaneLayout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(contentPaneLayout.createParallelGroup()
                                        .addGroup(contentPaneLayout.createSequentialGroup()
                                                .addComponent(botton1, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(botton2, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(botton3, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE))
                                        .addGroup(contentPaneLayout.createSequentialGroup()
                                                .addComponent(botton4, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(botton5, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(botton6, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE))
                                        .addGroup(contentPaneLayout.createSequentialGroup()
                                                .addComponent(botton7, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(botton8, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(botton9, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)))
                                .addContainerGap(10, Short.MAX_VALUE))
        );
        contentPaneLayout.setVerticalGroup(
                contentPaneLayout.createParallelGroup()
                        .addGroup(contentPaneLayout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(botton1, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(botton2, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(botton3, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(botton4, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(botton5, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(botton6, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(contentPaneLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                        .addComponent(botton7, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(botton8, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(botton9, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(15, Short.MAX_VALUE))
        );
        pack();
        setLocationRelativeTo(getOwner());
    }

}
